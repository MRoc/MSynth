#include "LMWindow.h"
#include <framework/treedocument/MSaxTreeDocument.h>
#include <gui/label/MLabel.h>

/** constructor */
LMWindow::LMWindow( LMModule* pModule ) :
	ivPtModule(pModule)
{
	ivBkColor = MColorMap::create( 180, 180, 210 );
	setActionOnClose(MTopWnd::ActionOnClose::QUIT);
}

/** destructor */
LMWindow::~LMWindow()
{
}

/** creates the window and audio engine */
bool LMWindow::create( MRect rect, MTopWnd* pParent )
{
	MSaxTreeDocument doc;
	doc.parseResource( "resource/ui/lm.layout.xml" );
	load( doc.getRoot() );

	bool back = MTopWnd::create( ivRect, pParent );

	ivPtModule->traceTree(0);
	ivPtModule->connect( "", this->getNamespace() );

	return back;
}

/** query for interface */
void* LMWindow::getInterface( const String& className ) const
{
	if( className == "LMWindow" )
		return (void*) ((LMWindow*)this);
	else
		return MTopWnd::getInterface( className );
}
