#include "LMtrack.h"
#include "LMEvent.h"
#include <audio/buffer/MSoundbufferUtils.h>

INIT_RTTI_CREATE(LMTrack, "LMTrack");

/** constructor */
LMTrack::LMTrack( const String& name, LMNode* pParent ) :
	LMNode(name , pParent)
{
	ivPtVolume = new MFloatControl(
		"volume",
		0.0f,
		1.0f,
		0.9f,
		false,
		MFloatControl::CURVE_LINEAR);

	ivPtPanorama = new MFloatControl(
		"panorama",
		0.0f,
		1.0f,
		0.5f,
		false,
		MFloatControl::CURVE_LINEAR);

	ivPtMute = new MBoolControl(
		"mute",
		false );

	ivControls.add(ivPtVolume);
	ivControls.add(ivPtPanorama);
	ivControls.add(ivPtMute);
}

/** destructor */
LMTrack::~LMTrack()
{
}

/** loads a wave file */
void LMTrack::loadFile(String fileName)
{
	LMLoop* pLoop = new LMLoop( this );
	pLoop->loadFile( fileName );
	ivChilds.add(pLoop);
	if( ivChilds.getLength() == 1 )
		ivChilds.setSelection(0);
}

/** fire a event into the processor */
void LMTrack::processEvent( MEvent* ptEvent )
{
	switch( ((LMEvent*)ptEvent)->getType() )
	{
	case LMEvent::TRACK_VOLUME:
		ivPtVolume->setValue( ((LMEvent*)ptEvent)->getValue<float>() );
		break;
	case LMEvent::TRACK_MUTE:
		ivPtMute->setValue( ((LMEvent*)ptEvent)->getValue<bool>() );
		break;
	case LMEvent::TRACK_PANORAMA:
		ivPtPanorama->setValue( ((LMEvent*)ptEvent)->getValue<float>() );
		break;
	case LMEvent::TRACK_LOOP_SELECTION:
		ivChilds.setSelection( ((LMEvent*)ptEvent)->getValue<int>() );
		break;
	default:
		forwardEvent( ptEvent );
		break;
	}
}

/** processes the given data */
void LMTrack::goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt)
{
	if( ! ivPtMute->getValue() && getSelectedLoop() )
	{
		MSoundBuffer tmp( buffer->getChannelCount(), stopAt-startFrom );
		getSelectedLoop()->goNext( &tmp, 0, stopAt-startFrom );
		MSoundBufferUtils::steroVolume(
			&tmp,
			0,
			stopAt-startFrom,
			ivPtVolume->getValue(),
			ivPtPanorama->getValue() );
		MSoundBufferUtils::add(
			buffer,
			&tmp,
			startFrom,
			stopAt-startFrom );
	}
}

/** returns the selected loop */
LMLoop* LMTrack::getSelectedLoop()
{
	return (LMLoop*)ivChilds.getSelectedObject();
}

void LMTrack::forwardEvent( MEvent* pEvent )
{
	MObjectListIterator iter = getControls();
	while( iter.hasNext() )
	{
		MObject* obj = iter.next();
		IProcessor* pProc = MCast(obj, IProcessor, "IProcessor");
		if( pProc )
		{
			pProc->processEvent( pEvent );
		}
	}

	iter = getChilds();
	while( iter.hasNext() )
	{
		MObject* obj = iter.next();
		IProcessor* pProc = MCast(obj, IProcessor, "IProcessor");
		if( pProc )
		{
			pProc->processEvent( pEvent );
		}
	}
}

/**
	* invoked by internal state change in a control
	*/
void LMTrack::valueChanged( MControlListenerEvent *anEvent )
{
	TRACE( "what the fuck: %s\n", anEvent->getSource()->getName().getData());
}

void LMTrack::load( MTreeNode* ptNode )
{
	LMNode::load(ptNode);
	ivChilds.setSelection(
		MInt::parse(
			ptNode->getAttribute("selection", "0") ));
}

MTreeNode* LMTrack::save()
{
	MTreeNode* pBack = LMNode::save();
	pBack->setAttribute( "selected", MInt::toString( ivChilds.getSelection() ));
	return pBack;
}

void* LMTrack::getInterface(const String& className) const
{
	if(className=="LMTrack")
		return (void*) ((LMTrack*)this);
	else if(className=="IProcessor")
		return (void*) ((IProcessor*)this);
	else
		return LMNode::getInterface(className);
}

IRtti* LMTrack::getRtti() const
{
	return &gvRtti;
}

MObject* LMTrack::createInstance()
{
	return new LMTrack();
}