#ifndef __LMLoop
#define __LMLoop

#include <audio/processor/IProcessor.h>
#include <audio/file/MWave.h>
#include "LMNode.h"

/** a track contained in a module */
class LMLoop :
	public LMNode,
	public IProcessor
{
public:

	static MRtti gvRtti;

protected:

	/** the loaded wave file */
	MWave* ivPtWave;

	/** the tempo */
	FP ivBpm;

	/** the current play position */
	FP ivPlayPos;

	/** the filename */
	String ivFileName;

public:

	/** constructor */
	LMLoop(LMNode* pParent = NULL);

	/** destructor */
	virtual ~LMLoop();

	/** load a wave file */
	virtual void loadFile(String fileName);

	/** fire a event into the processor */
	virtual void processEvent( MEvent* ptEvent );

	/** processes the given data */
	virtual void goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt);

	/** returns the filename */
	virtual String getFileName() const;

	virtual void load( MTreeNode* ptNode );
	virtual MTreeNode* save();

	static MObject* createInstance();
	virtual IRtti* getRtti() const;
	virtual void* getInterface(const String& className) const;

protected:

	/** the interpolation algorythm for mono and stereo samples */
	FP render(
		MSoundBuffer* buffer,
		unsigned int start,
		unsigned int len,
		FP playpos,
		FP playposIncrement,
		FP multi);

};

#endif