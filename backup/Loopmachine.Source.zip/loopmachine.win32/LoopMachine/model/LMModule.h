#ifndef __LMModule
#define __LMModule

#include <audio/processor/IProcessor.h>
#include <framework/list/MObjectList.h>
#include <framework/list/MObjectListIterator.h>
#include "LMTrack.h"
#include "LMNode.h"
#include "LMScheduler.h"

/** the module like in specification */
class LMModule :
	public LMNode,
	public IProcessor
{
public:

	FULL_RTTI_SUPER(LMModule, "LMModule", LMNode);

	/** constructor */
	LMModule();

	/** destructor */
	virtual ~LMModule();

	/** creates the given number of tracks */
	void init(unsigned int trackCount);

	/** fire a event into the processor */
	virtual void processEvent( MEvent* ptEvent );

	/** processes the given data */
	virtual void goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt);
};

#endif