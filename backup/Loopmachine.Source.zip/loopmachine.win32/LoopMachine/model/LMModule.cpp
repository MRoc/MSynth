#include "LMModule.h"

INIT_RTTI(LMModule, "LMModule");

/** constructor */
LMModule::LMModule() :
	LMNode("module", NULL)
{
	ivChilds.add( new LMScheduler(this) );
}

/** destructor */
LMModule::~LMModule()
{
}

/** creates the given number of tracks */
void LMModule::init(unsigned int trackCount)
{
	for( unsigned int i=0;i<trackCount;i++ )
	{
		LMTrack* newTrack =
			new LMTrack(
				"track" + MInt::toString(ivChilds.getLength()), 
				this );
		newTrack->loadFile( "resource/audio/loop" + MInt::toString(i+1) + ".wav" );
		ivChilds.add( newTrack );
	}
}

/** fire a event into the processor */
void LMModule::processEvent( MEvent* ptEvent )
{
	MObjectListIterator i = getChilds();
	while( i.hasNext() )
	{
		IProcessor* pProc = MCast( i.next(), IProcessor, "IProcessor");
		ASSERT( pProc );
		pProc->processEvent(ptEvent);
	}
}

/** processes the given data */
void LMModule::goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt)
{
	LMScheduler* pScheduler = MCast(ivChilds.get(0), LMScheduler, "LMScheduler");
	int nextEvent = pScheduler->getSamplesUntilNextEvent();
	int toRender = (int)(stopAt-startFrom);

	if( toRender < nextEvent )
	{
		MObjectListIterator i = getChilds();
		while( i.hasNext() )
		{
			IProcessor* pProc = MCast( i.next(), IProcessor, "IProcessor");
			ASSERT( pProc );
			pProc->goNext(buffer, startFrom, stopAt);
		}
	}
	else
	{
		int rendered = 0;
		int start = startFrom;
		while( rendered < toRender )
		{
			int stop = start + pScheduler->getSamplesUntilNextEvent();
			if( stop >= (int)stopAt )
				stop = stopAt;
			if( start != stop )
			{
				MObjectListIterator i = getChilds();
				while( i.hasNext() )
				{
					IProcessor* pProc = MCast( i.next(), IProcessor, "IProcessor");
					ASSERT( pProc );
					pProc->goNext(buffer, start, stop);
				}
				start = stop;
			}
			rendered += nextEvent;
			pScheduler->trigger();
		}
	}
}
