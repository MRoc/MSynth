#ifndef __LMNode
#define __LMNode

#include <framework/MObject.h>
#include <framework/runtime/MRtti.h>
#include <framework/list/MSelectableObjectList.h>
#include <framework/treedocument/ISerializeable.h>
#include <framework/treedocument/MTreeNode.h>
#include "ILMControlList.h"
#include <gui/MWndNamespace.h>

class LMNode :
	public MObject,
	public ISerializeable,
	public ILMControlList
{
public:

	static MRtti gvRtti;

protected:

	LMNode* ivPtParent;

	String ivName;

	MSelectableObjectList ivChilds;
	MSelectableObjectList ivControls;

public:

	explicit LMNode( String name, LMNode* pParent = NULL );
	virtual ~LMNode();

	virtual String getName() const;
	virtual MObjectListIterator getControls();

	virtual LMNode* getParent();
	virtual MObjectListIterator getChilds();

	virtual IRtti* getRtti() const;
	virtual void* getInterface(const String& className) const;
	static MObject* createInstance();

	virtual void connect( String preId, MWndNamespace* pNS );

	virtual void traceTree( int depth );

	virtual void load( MTreeNode* ptNode );
	virtual MTreeNode* save();

protected:

	virtual IControl* getControlByName( const String& name );
};

#endif