#ifndef __ILMControlList
#define __ILMControlList

#include <framework/list/MObjectListIterator.h>
#include <gui/control/model/IControl.h>


class ILMControlList
{
public:

	virtual String getName() const = 0;
	virtual MObjectListIterator getControls() = 0;
};

#endif