#ifndef __LMScheduler
#define __LMScheduler

#include <audio/processor/IProcessor.h>
#include "LMEvent.h"
#include "IMScheduler.h"
#include <list>
#include "LMNode.h"

class LMScheduler :
	public LMNode,
	public IMScheduler,
	public IProcessor
{
public:

	static MRtti gvRtti;

protected:

	class LMSchedulerEntry
	{
	protected:
		LMEvent* ivPtEvent;
		int ivTime;
	public:
		LMSchedulerEntry();
		LMSchedulerEntry(LMEvent* pEvent, int time);
		LMSchedulerEntry( const LMSchedulerEntry& entry );
		virtual ~LMSchedulerEntry();
		virtual LMEvent* getEvent() const;
		virtual int getTime() const;
		bool operator==(const LMSchedulerEntry& entry);
		bool operator!=(const LMSchedulerEntry& entry);
		bool operator<(const LMSchedulerEntry& entry);
		bool operator>(const LMSchedulerEntry& entry);
	};

	typedef std::list<LMSchedulerEntry> LMSList;
	typedef LMSList::iterator LMSListIter;

	LMSList ivEvents;
	FP ivBpm;
	int ivSamplesRendered;

	LMEvent ivEvent;

public:

	/** scheduler */
	LMScheduler(LMNode* pParent);

	/** destructor */
	virtual ~LMScheduler();

	/** returns the number of samples until the next event */
	virtual int getSamplesUntilNextEvent();

	/** triggers the current events */
	virtual void trigger();

	/** returns the runtime type info */
	virtual IRtti* getRtti() const;

	/** query interface */
	virtual void* getInterface(const String& className) const;

	/** fire a event into the processor */
	virtual void processEvent( MEvent* ptEvent );

	/** processes the given data */
	virtual void goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt);

private:

	/** schedules a event at a specified position */
	virtual void schedule(LMEvent* pEvent, int samplePosition);
};

#endif