#include "LMScheduler.h"
#include <framework/primitive/MInt.h>
#include <framework/io/MLogger.h>
#include "LMModule.h"

MRtti LMScheduler::gvRtti = MRtti("LMScheduler", NULL);

LMScheduler::LMSchedulerEntry::LMSchedulerEntry() :
	ivPtEvent(NULL),
	ivTime(0)
{
}

LMScheduler::LMSchedulerEntry::LMSchedulerEntry(LMEvent* pEvent, int time) :
	ivPtEvent(pEvent),
	ivTime(time)
{
}

LMScheduler::LMSchedulerEntry::LMSchedulerEntry( const LMSchedulerEntry& entry ) :
	ivPtEvent(entry.getEvent()),
	ivTime(entry.getTime())
{
}

LMScheduler::LMSchedulerEntry::~LMSchedulerEntry()
{
}

LMEvent* LMScheduler::LMSchedulerEntry::getEvent() const
{
	return ivPtEvent;
}

int LMScheduler::LMSchedulerEntry::getTime() const
{
	return ivTime;
}

bool LMScheduler::LMSchedulerEntry::operator==(const LMSchedulerEntry& entry)
{
	return ivTime == entry.getTime();
}

bool LMScheduler::LMSchedulerEntry::operator!=(const LMSchedulerEntry& entry)
{
	return ivTime != entry.getTime();
}

bool LMScheduler::LMSchedulerEntry::operator<(const LMSchedulerEntry& entry)
{
	return ivTime < entry.getTime();
}

bool LMScheduler::LMSchedulerEntry::operator>(const LMSchedulerEntry& entry)
{
	return ivTime > entry.getTime();
}

/** scheduler */
LMScheduler::LMScheduler(LMNode* pParent) :
	LMNode("scheduler", pParent),
	ivBpm(120.0f),
	ivSamplesRendered(0),
	ivEvent(LMEvent::LOOP_RESET)
{
	schedule(&ivEvent, (int)(( 240.0f / ivBpm ) * MW_SAMPLINGRATE) );
}

/** destructor */
LMScheduler::~LMScheduler()
{
}

/** schedules a event at a specified position */
void LMScheduler::schedule(LMEvent* pEvent, int samplePosition)
{
	LMSListIter i = ivEvents.begin();
	while( i!=ivEvents.end() && samplePosition > i->getTime() )
		i++;
	ivEvents.insert(i, LMSchedulerEntry(pEvent, samplePosition));
}

/** returns the number of samples until the next event */
int LMScheduler::getSamplesUntilNextEvent()
{
	if (ivEvents.size() > 0 )
		return ivEvents.begin()->getTime() - ivSamplesRendered;
	else
		return MInt::MAX_INT;
}

/** triggers the current events */
void LMScheduler::trigger()
{
	LMSListIter i = ivEvents.begin();
	while( i!=ivEvents.end() && ivSamplesRendered == i->getTime() )
	{
		((LMModule*)getParent())->processEvent( i->getEvent() );
		ivEvents.erase(i);
		i=ivEvents.begin();
	}
}

/** returns the runtime type info */
IRtti* LMScheduler::getRtti() const
{
	return &gvRtti;
}

/** query interface */
void* LMScheduler::getInterface(const String& className) const
{
	if( className == "LMScheduler" )
		return (void*) ((LMScheduler*)this);
	else if( className == "IMScheduler" )
		return (void*) ((IMScheduler*)this);
	else if( className == "IProcessor" )
		return (void*) ((IProcessor*)this);
	else
		return LMNode::getInterface(className);
}

/** fire a event into the processor */
void LMScheduler::processEvent( MEvent* ptEvent )
{
	LMEvent* pLmEvent = (LMEvent*)ptEvent;
	if( pLmEvent->getType() == LMEvent::TEMPO_CHANGE )
		ivBpm = pLmEvent->getValue<float>();
	else if( pLmEvent->getType() == LMEvent::LOOP_RESET )
	{
		ivSamplesRendered = 0;
		schedule(&ivEvent, (int)(( 240.0f / ivBpm ) * MW_SAMPLINGRATE) );
	}
}

/** processes the given data */
void LMScheduler::goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt)
{
	int nextEvent = getSamplesUntilNextEvent();
	if( (int)(stopAt - startFrom) > nextEvent )
		MLogger::logError( "lms.goNext: state corrupted! events would be skipped!");

	ivSamplesRendered += (int)(stopAt - startFrom);
}