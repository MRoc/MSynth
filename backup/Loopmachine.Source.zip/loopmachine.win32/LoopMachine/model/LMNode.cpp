#include "LMNode.h"
#include <framework/MUtil.h>
#include <framework/io/MLogger.h>
#include <gui/control/model/MDefaultControl.h>
#include <gui/control/view/MControlGui.h>
#include <framework/treedocument/MTreeDocumentUtils.h>


MRtti LMNode::gvRtti = MRtti( "LMNode", LMNode::createInstance );

LMNode::LMNode( String name, LMNode* pParent ) :
	ivPtParent(pParent),
	ivName(name)
{
}

LMNode::~LMNode()
{
	ivChilds.deleteAll();
	ivControls.deleteAll();
}

String LMNode::getName() const
{
	return ivName;
}

MObjectListIterator LMNode::getControls()
{
	return MObjectListIterator(&ivControls);
}

LMNode* LMNode::getParent()
{
	return ivPtParent;
}

MObjectListIterator LMNode::getChilds()
{
	return MObjectListIterator(&ivChilds);
}


IRtti* LMNode::getRtti() const
{
	return &gvRtti;
}

void* LMNode::getInterface(const String& className) const
{
	if( className == "LMNode" )
		return (void*) ((LMNode*)this);
	else if( className == "ISerializeable" )
		return (void*) ((ISerializeable*)this);
	else if( className == "ILMControlList" )
		return (void*) ((ILMControlList*)this);
	else
		return MObject::getInterface(className);
}

MObject* LMNode::createInstance()
{
	return new LMNode( "root", NULL );
}

void LMNode::traceTree( int depth )
{
	MLogger::logMessage(
		"%s%s: \"%s\"\n",
		MUtil::getTabs(depth).getData(),
		getRtti()->getClassName(),
		getName().getData());

	MObjectListIterator i = getChilds();
	while(i.hasNext())
	{
		MObject* next = i.next();
		((LMNode*)next->getInterface("LMNode"))->traceTree(depth+1);
	}
}

void LMNode::connect( String preId, MWndNamespace* pNS )
{
	ASSERT( pNS );
	MObjectListIterator i(&ivControls);
	while( i.hasNext() )
	{
		MDefaultControl* pControl = (MDefaultControl*)i.next()->getInterface("MDefaultControl");
		String id = pControl->getName();
		String fullId = preId + ivName + "." + id;
		MObject* pObj = pNS->getObj( fullId );
		if( pObj )
		{
			MControlGui* pGui = (MControlGui*) pObj->getInterface("MControlGui");
			if( pGui )
				pGui->setControl(pControl);
			else
				MLogger::logWarning(
					"object with id \"%s\" does not inherit from MControlGui",
					fullId.getData());
		}
		else
			MLogger::logWarning(
				"could not resolve id \"%s\"",
				fullId.getData());
	}

	MObjectListIterator i2 = getChilds();
	while(i2.hasNext())
	{
		LMNode* pNode = MCast(i2.next(), LMNode, "LMNode");
		pNode->connect( preId + getName() + ".", pNS);
	}
}

void LMNode::load( MTreeNode* ptNode )
{
	ivName = ptNode->getAttribute( "name" );
	MTreeNodeIterator i = ptNode->getIterator();
	while( i.hasNext() )
	{
		MTreeNode* pChild = (MTreeNode*) i.nextTreeNode();
		if( pChild->getName() == "children" )
		{
			MTreeNodeIterator childs = pChild->getIterator();
			while( childs.hasNext() )
			{
				MObject* pNext = childs.nextTreeNode();
				if( pNext->getInterface("MTreeNode"))
				{
					MTreeNode* pChildNode = (MTreeNode*)pNext;
					MObject* newChild = MTreeDocumentUtils::createObject(pChildNode);
					if( newChild->getInterface("LMNode") )
						ivChilds.add( newChild );
				}
				else
					MLogger::logError(
					"node " + pNext->toString() + " is not a treenode" );
			}
		}
		else if( pChild->getName() == "controls" )
		{
			MTreeNodeIterator controls = pChild->getIterator();
			while( controls.hasNext() )
			{
				MTreeNode* pControlNode = (MTreeNode*)controls.nextTreeNode();
				String name = pControlNode->getAttribute("name");
				IControl* pControl = getControlByName(name);
				if( pControl )
					pControl->load(pControlNode);
			}
		}
	}
}

MTreeNode* LMNode::save()
{
	MTreeNode* pBack = new MTreeNode(MObject::ELEM_OBJECT);
	pBack->setAttribute(MObject::ATTR_CLASS, getRtti()->getClassName());
	pBack->setAttribute("name", ivName);

	if( ivControls.getLength() )
	{
		MTreeNode* pControlNode = new MTreeNode("controls");
		pBack->addChild(pControlNode);
		MObjectListIterator i1(&ivControls);
		while( i1.hasNext() )
		{
			MDefaultControl* pControl = MCast(i1.next(), MDefaultControl, "MDefaultControl");
			pControlNode->addChild( pControl->save() );
		}
	}

	if(ivChilds.getLength())
	{
		MTreeNode* pChildNode = new MTreeNode("children");
		pBack->addChild(pChildNode);
		MObjectListIterator i2(&ivChilds);
		while( i2.hasNext() )
		{
			LMNode* pNode = MCast(i2.next(), LMNode, "LMNode");
			pChildNode->addChild( pNode->save() );
		}
	}

	return pBack;
}

IControl* LMNode::getControlByName( const String& name )
{
	MObjectListIterator i(&ivControls);
	while( i.hasNext() )
	{
		MDefaultControl* pControl = MCast(i.next(), MDefaultControl, "MDefaultControl");
		if( pControl && pControl->getName() == name )
			return pControl;
	}
	return NULL;
}