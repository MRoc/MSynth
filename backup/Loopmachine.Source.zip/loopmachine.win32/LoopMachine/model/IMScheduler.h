#ifndef __IMScheduler
#define __IMScheduler

#include <audio/processor/IProcessor.h>

class IMScheduler
{
public:

	/** schedules a event at a specified position */
	virtual void schedule(LMEvent* pEvent, int samplePosition) = 0;
};

#endif