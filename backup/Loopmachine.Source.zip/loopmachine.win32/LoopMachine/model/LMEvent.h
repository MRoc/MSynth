#ifndef __LMEvent
#define __LMEvent

#include <audio/event/MEvent.h>

class LMEvent :
	public MEvent
{
public:

	/** the loop machine event type definition */
	enum Type
	{
		LOOP_RESET,
		TEMPO_CHANGE,
		TRACK_VOLUME,
		TRACK_MUTE,
		TRACK_PANORAMA,
		TRACK_LOOP_SELECTION
	};

	/** the event's value type */
	enum ValueType
	{
		NONE,
		INTEGER,
		FLOAT,
		BOOL
	};


protected:

	/** the loop machine event type */
	Type ivType;

	/** the value's type */
	ValueType ivValueType;

	/** the event's data field */
	char ivValue[4];

public:

	/** constructor */
	LMEvent( Type type );

	/** constructor */
	explicit LMEvent( Type type, float f );

	/** constructor */
	explicit LMEvent( Type type, int i );

	/** constructor */
	explicit LMEvent( Type type, bool i );

	/** destructor */
	virtual ~LMEvent();

	/** returns the event's type */
	Type getType() const;

	/** returns the event's value as template member */
	template<class T> T getValue() const
	{
		ASSERT(sizeof(T)<=4);
		T back;
		memcpy(&back,ivValue,sizeof(T));
		return back;
	};
};

#endif