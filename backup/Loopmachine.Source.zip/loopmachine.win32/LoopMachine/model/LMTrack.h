#ifndef __LMTrack
#define __LMTrack

#include <audio/processor/IProcessor.h>
#include <framework/list/MSelectableObjectList.h>
#include <framework/list/MObjectListIterator.h>
#include "LMLoop.h"
#include "LMNode.h"
#include <gui/control/model/MFloatControl.h>
#include <gui/control/model/MBoolControl.h>

/** a track contained in a module */
class LMTrack :
	public LMNode,
	public IControlListener,
	public IProcessor
{
protected:

	static MRtti gvRtti;

	/** the track volume */
	MFloatControl* ivPtVolume;

	/** track stereo panorama */
	MFloatControl* ivPtPanorama;

	/** mutes the track */
	MBoolControl* ivPtMute;

public:

	/** constructor */
	LMTrack( const String& name = "track", LMNode* pParent = NULL );

	/** destructor */
	virtual ~LMTrack();

	/** loads a wave file */
	virtual void loadFile(String fileName);

	/** fire a event into the processor */
	virtual void processEvent( MEvent* ptEvent );

	/** processes the given data */
	virtual void goNext( MSoundBuffer* buffer, unsigned int startFrom, unsigned int stopAt);

	/** returns the selected loop */
	virtual LMLoop* getSelectedLoop();

	/**
	 * invoked by internal state change in a control
	 */
	virtual void valueChanged( MControlListenerEvent *anEvent );

	virtual void load( MTreeNode* ptNode );
	virtual MTreeNode* save();

	virtual void* getInterface(const String& className)const;
	virtual IRtti* getRtti() const;
	static MObject* createInstance();

protected:

	void forwardEvent( MEvent* pEvent );

};

#endif