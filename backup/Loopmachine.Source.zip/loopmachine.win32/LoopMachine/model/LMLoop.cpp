#include "LMLoop.h"
#include "LMEvent.h"
#include <audio/buffer/MSoundbufferUtils.h>
#include <framework/io/MLogger.h>

MRtti LMLoop::gvRtti = MRtti( "LMLoop", LMLoop::createInstance);

/** constructor */
LMLoop::LMLoop(LMNode* pParent) :
	LMNode("loop", pParent),
	ivPtWave( 0 ),
	ivBpm( 120 ),
	ivPlayPos( 0.0f )
{
}

/** destructor */
LMLoop::~LMLoop()
{
	SAFE_DELETE(ivPtWave);
}

/** load a wave file */
void LMLoop::loadFile(String fileName)
{
	ivFileName = fileName;
	if( !ivPtWave )
		ivPtWave = new MWave();
	ivPtWave->loadResource(fileName);
}

/** fire a event into the processor */
void LMLoop::processEvent( MEvent* ptEvent )
{
	switch( ((LMEvent*)ptEvent)->getType() )
	{
	case LMEvent::LOOP_RESET: ivPlayPos = 0.0f; break;
	case LMEvent::TEMPO_CHANGE: ivBpm = ((LMEvent*)ptEvent)->getValue<float>(); break;
	}
}

/** processes the given data */
void LMLoop::goNext( MSoundBuffer* buffer, unsigned int renderFrom, unsigned int renderTo)
{
	// return if waveplayer is in an invalid state...
	if( ivPtWave && ivPtWave->getData() && ivPtWave->getDataLength() )
	{
		unsigned int sampleLength = ivPtWave->getDataLength() / ( ivPtWave->getChannelCount() * sizeof(MW_SAMPLETYPE) );
		unsigned int modSampleLength = sampleLength - 1;
		FP playPosDelta = sampleLength / ( ( 240.0f / ivBpm ) * MW_SAMPLINGRATE );
		unsigned int samplesToRender = renderTo - renderFrom;
		unsigned int samplesRendered = 0;

		MSoundBuffer tmpBuffer( ivPtWave->getChannelCount(), samplesToRender );

		while( samplesRendered < samplesToRender )
		{
			unsigned int samplesLeftInWave = (unsigned int)(modSampleLength - ivPlayPos);
			unsigned int renderNow = (unsigned int) (samplesLeftInWave / playPosDelta);
			if( samplesRendered + renderNow > samplesToRender )
				renderNow = samplesToRender - samplesRendered;

			if( renderNow != 0 ) 
				ivPlayPos = render(&tmpBuffer, samplesRendered, renderNow, ivPlayPos,playPosDelta, 1.0f );
			else
				ivPlayPos = 0.0f;

			if( ivPlayPos >= modSampleLength )
				ivPlayPos = 0.0f;

			samplesRendered += renderNow;
		}

		MSoundBufferUtils::addStereo(
			buffer,
			&tmpBuffer,
			1/MW_MAX,
			0.5f );
	}
}

/** the interpolation algorythm for mono and stereo samples */
FP LMLoop::render(
	MSoundBuffer* buffer,
	unsigned int start,
	unsigned int len,
	FP playpos,
	FP playposIncrement,
	FP multi )
{
	FP oldPP = playpos;
	MW_SAMPLETYPE* pSample = (MW_SAMPLETYPE*) ivPtWave->getData();
	unsigned int sampleLength = ivPtWave->getDataLength() / ( ivPtWave->getChannelCount() * sizeof(MW_SAMPLETYPE) );

	unsigned int iter = 0;

	// required for inerpolation...
	unsigned int i1, i2;

	// render...
	if( ivPtWave->getChannelCount() == 1 )
	{
		FP* ptStart = buffer->getData( 0 ) + start;
		FP* ptStop = ptStart + len;
		for( FP *pt=ptStart;pt<ptStop;pt++ )
		{
			// linear interpolation
			i1 = unsigned int(playpos);
			i2 = i1 + 1;
			ASSERT( i1 < unsigned int( sampleLength ) );
			ASSERT( i2 < unsigned int( sampleLength ) );
			(*pt) = ((pSample[i2]-pSample[i1]) * (playpos - i1) + pSample[i1]) * multi;

			playpos = oldPP + (++iter) * playposIncrement; 
		}
	}
	else if( ivPtWave->getChannelCount() == 2 )
	{
		FP* ptStart1 = buffer->getData( 0 ) + start;
		FP* ptStop1 = ptStart1 + len;
		FP* ptStart2 = buffer->getData( 1 ) + start;
		FP* ptStop2 = ptStart2 + len;
		FP* pt1 = ptStart1;
		FP* pt2 = ptStart2;
		unsigned int i12, i22;
		for( ;pt1<ptStop1;pt1++,pt2++ )
		{
			// linear interpolation
			i1 = unsigned int(playpos);
			i2 = i1 + 1;
			ASSERT( i1 < unsigned int( sampleLength ) );
			ASSERT( i2 < unsigned int( sampleLength ) );

			i12 = i1*2;
			i22 = i2*2;
			(*pt1) = ((pSample[i22]-pSample[i12]) * (playpos - i1) + pSample[i12]) * multi;
			(*pt2) = ((pSample[i22+1]-pSample[i12+1]) * (playpos - i1) + pSample[i12+1]) * multi;

			playpos = oldPP + (++iter) * playposIncrement; 
		}
	}

	return playpos;
}

/** returns the filename */
String LMLoop::getFileName() const
{
	return ivFileName;
}

void LMLoop::load( MTreeNode* ptNode )
{
	LMNode::load(ptNode);
	String fileName(ptNode->getAttribute("filename"));
	try
	{
		loadFile(fileName);
	}
	catch( const MException& ex )
	{
		MLogger::logWarning(
			"error loading loop \"%s\":\n%s",
			fileName.getData(),
			ex.getExceptionDescripton().getData());

	}
}

MTreeNode* LMLoop::save()
{
	MTreeNode* pBack = LMNode::save();
	pBack->setAttribute( "filename", ivFileName );
	return pBack;
}

MObject* LMLoop::createInstance()
{
	return new LMLoop();
}

IRtti* LMLoop::getRtti() const
{
	return &gvRtti;
}

void* LMLoop::getInterface(const String& className) const
{
	if( className == "LMLoop" )
		return (void*)((LMLoop*)this);
	else if( className == "IProcessor" )
		return (void*)((IProcessor*)this);
	else 
		return LMNode::getInterface(className);
}