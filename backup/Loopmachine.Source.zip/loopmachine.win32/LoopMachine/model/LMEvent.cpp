#include "LMEvent.h"

/** constructor */
LMEvent::LMEvent( Type type ) :
	ivType(type)
{
	memset(ivValue, 0, 4);
	switch(type)
	{
		case LOOP_RESET: ivValueType = NONE; break;
		case TEMPO_CHANGE: ivValueType = FLOAT; break;
		case TRACK_VOLUME: ivValueType = FLOAT; break;
		case TRACK_MUTE: ivValueType = BOOL; break;
		case TRACK_PANORAMA: ivValueType = FLOAT; break;
		case TRACK_LOOP_SELECTION: ivValueType = INTEGER; break;
		default: ASSERT( false ); break;
	}
}

/** constructor */
LMEvent::LMEvent( Type type, float f ) :
	ivType(type)
{
	memcpy(ivValue, &f, sizeof(float));
	switch(type)
	{
		case LOOP_RESET: ivValueType = NONE; break;
		case TEMPO_CHANGE: ivValueType = FLOAT; break;
		case TRACK_VOLUME: ivValueType = FLOAT; break;
		case TRACK_MUTE: ivValueType = BOOL; break;
		case TRACK_PANORAMA: ivValueType = FLOAT; break;
		case TRACK_LOOP_SELECTION: ivValueType = INTEGER; break;
		default: ASSERT( false ); break;
	}
}

/** constructor */
LMEvent::LMEvent( Type type, int i ) :
	ivType(type)
{
	memcpy(ivValue, &i, sizeof(int));
	switch(type)
	{
		case LOOP_RESET: ivValueType = NONE; break;
		case TEMPO_CHANGE: ivValueType = FLOAT; break;
		case TRACK_VOLUME: ivValueType = FLOAT; break;
		case TRACK_MUTE: ivValueType = BOOL; break;
		case TRACK_PANORAMA: ivValueType = FLOAT; break;
		case TRACK_LOOP_SELECTION: ivValueType = INTEGER; break;
		default: ASSERT( false ); break;
	}
}

/** constructor */
LMEvent::LMEvent( Type type, bool i ) :
	ivType(type)
{
	memcpy(ivValue, &i, sizeof(bool));
	switch(type)
	{
		case LOOP_RESET: ivValueType = NONE; break;
		case TEMPO_CHANGE: ivValueType = INTEGER; break;
		case TRACK_VOLUME: ivValueType = FLOAT; break;
		case TRACK_MUTE: ivValueType = BOOL; break;
		case TRACK_PANORAMA: ivValueType = FLOAT; break;
		case TRACK_LOOP_SELECTION: ivValueType = INTEGER; break;
		default: ASSERT( false ); break;
	}
}

/** destructor */
LMEvent::~LMEvent()
{
}

/** returns the event's type */
LMEvent::Type LMEvent::getType() const
{
	return ivType;
}

/** returns the event's value as template member */
/*template<class T> T LMEvent::getValue() const
{
	ASSERT(sizeof(T)<=4);
	T back;
	memcpy(&back,ivValue,sizeof(T));
	return back;
}*/