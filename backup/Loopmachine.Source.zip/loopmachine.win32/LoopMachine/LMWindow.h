#ifndef __LMWindow
#define __LMWindow

#include <gui/MTopWnd.h>
#include <audio/engine/MAudioEngine.h>
#include "model/LMModule.h"

class LMWindow :
	public MTopWnd
{
protected:

	LMModule* ivPtModule;

public:

	/** constructor */
	LMWindow( LMModule* pModule );

	/** destructor */
	virtual ~LMWindow();

	/** creates the window and audio engine */
	virtual bool create( MRect rect, MTopWnd* pParent );

	/** query for interface */
	virtual void* getInterface( const String& className ) const;
};

#endif