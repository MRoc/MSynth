#include <framework/MTypes.h>
#include <framework/MNativeTypes.h>
#include <framework/MObject.h>
#include <framework/IRtti.h>
#include <framework/runtime/MRtti.h>

#include <gui/MFont.h>
#include <gui/MImage.h>
#include <gui/MTopWnd.h>
#include <gui/MUiGraphics.h>
#include <gui/MWnd.h>
#include <gui/MWndCollection.h>
#include <gui/button/MArrowButtonRenderer.h>
#include <gui/button/MButton.h>
#include <gui/button/MCheckBoxRenderer.h>
#include <gui/button/MFlatTextButtonRenderer.h>
#include <gui/button/MMultiToggleButtonControl.h>
#include <gui/button/MOkButton.h>
#include <gui/button/MRadioButtonRenderer.h>
#include <gui/button/MTextButtonRenderer.h>
#include <gui/button/MToggleButton.h>
#include <gui/button/MTransparentBitmapButtonRenderer.h>
#include <gui/framewnd/MFrameWnd.h>
#include <gui/framewnd/MRootPane.h>
#include <gui/framewnd/MScrolledFrameWnd.h>
#include <gui/label/MLabel.h>
#include <gui/label/MObjectLabel.h>
#include <gui/framewnd/MFrameWnd.h>
#include <gui/framewnd/MFrameWnd.h>
#include <gui/layout/MLayout.h>
#include <gui/layout/MLayoutCol.h>
#include <gui/layout/MLayoutLeaf.h>
#include <gui/layout/MLayoutNode.h>
#include <gui/layout/MLayoutRoot.h>
#include <gui/layout/MLayoutRow.h>
#include <gui/layout/MLayoutWnd.h>
#include <gui/net/MLink.h>
#include <gui/popup/MPopupWnd.h>
#include <gui/scrollbar/MScrollBar.h>
#include <gui/scrollbar/MScrollBarBed.h>
#include <gui/scrollbar/MScrollBarButton.h>
#include <gui/scrollbar/MScrollBarController.h>
#include <gui/scrollbar/MScrollPane.h>
#include <gui/scrollbar/MSimpleScrollWnd.h>
#include <gui/progress/MProgressControl.h>
#include <gui/counter/MCountControl.h>
#include <gui/counter/MCounter.h>
#include <gui/textfield/MTextField.h>
#include <gui/textfield/MTextFieldRenderer.h>
#include <gui/list/MListView.h>
#include <gui/list/MScrolledListView.h>
#include <gui/combobox/MComboBox.h>
#include <gui/spinbutton/MSpinButton.h>
#include <gui/imagewnd/MImageWnd.h>
#include <gui/control/view/MVFloatGui.h>


#define MTraceRtti( ClassName ) \
	{ \
		String tmp; \
		tmp.format("<tracertti class=\"%s\" createable=\"%s\"/>\n", \
			ClassName::gvRtti.getClassName(), \
			ClassName::gvRtti.canCreate() ? "true" : "false"); \
		OutputDebugString(tmp.getData()); \
	}

void traceRttis()
{
	MTraceRtti(MFont);
	MTraceRtti(MImage);
	MTraceRtti(MTopWnd);
	MTraceRtti(MUiGraphics);
	MTraceRtti(MWnd);
	MTraceRtti(MWndCollection);

	MTraceRtti(MArrowButtonRenderer);
	MTraceRtti(MButton);
	MTraceRtti(MCheckBoxRenderer);
	MTraceRtti(MFlatTextButtonRenderer);
	MTraceRtti(MMultiToggleButtonControl);
	MTraceRtti(MOkButton);
	MTraceRtti(MRadioButtonRenderer);
	MTraceRtti(MTextButtonRenderer);
	MTraceRtti(MToggleButton);
	MTraceRtti(MTransparentBitmapButtonRenderer);

	MTraceRtti(MFrameWnd);
	MTraceRtti(MRootPane);
	MTraceRtti(MScrolledFrameWnd);

	MTraceRtti(MLabel);
	MTraceRtti(MObjectLabel);

	MTraceRtti(MLayout);
	MTraceRtti(MLayoutCol);
	MTraceRtti(MLayoutLeaf);
	MTraceRtti(MLayoutNode);
	MTraceRtti(MLayoutRoot);
	MTraceRtti(MLayoutRow);
	MTraceRtti(MLayoutWnd);

	MTraceRtti(MLink);

	MTraceRtti(MPopupWnd);

	MTraceRtti(MScrollBar);
	MTraceRtti(MScrollBarBed);
	MTraceRtti(MScrollBarButton);
	MTraceRtti(MScrollBarController);
	MTraceRtti(MScrollPane);
	MTraceRtti(MSimpleScrollWnd);

	MTraceRtti(MProgressControl);

	MTraceRtti(MCountControl);
	MTraceRtti(MCounter);

	MTraceRtti(MTextField);
	MTraceRtti(MTextFieldRenderer);

	MTraceRtti(MListView);
	MTraceRtti(MScrolledListView);

	MTraceRtti(MComboBox);

	MTraceRtti(MSpinButton);

	MTraceRtti(MImageWnd);

	MTraceRtti(MVFloatGui);
}