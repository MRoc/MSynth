#ifndef __LMApp
#define __LMApp

#include <gui\MApp.h>
#include <audio/engine/MAudioEngine.h>
#include "LMWindow.h"

class LMApp :
	public MApp
{
protected:

	/** the test window */
	LMWindow* ivPtWindow;

	/** the module */
	LMModule* ivPtModule;

	/** the audio engine */
	MAudioEngine* ivPtEngine;

public:

	/** constructor */
	LMApp();

	/** destructor */
	virtual ~LMApp();

	/** invoked when app is coming up */
	virtual bool onInit();

	/** invoked when app exists */
	virtual bool onExit();

	/** returns the application's name */
	virtual String getAppName(){ return "LoopMachine"; };
};

#endif