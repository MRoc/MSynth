#include "LMApp.h"
#include <framework/io/MIoException.h>
#include <framework/io/MLogger.h>
#include <framework/resource/MResourceManager.h>
#include <framework/treedocument/MTreeDocumentUtils.h>
#include <framework/treedocument/MSaxTreeDocument.h>
#include <gui/label/MLabel.h>


extern void traceRttis();

LMApp::LMApp() :
	ivPtWindow( 0 ),
	ivPtEngine(0)
{
	traceRttis();
}

LMApp::~LMApp()
{
}

MApp* createApp()
{
	return new LMApp();
}

bool LMApp::onInit()
{
//#ifndef _DEBUG
	String appDir = getAppDir();
/*#else
	String appDir = "D:/code/msynth/LoopMachine/";
#endif*/
	appDir.Replace( "\\", "/" );

	try
	{
		MResourceManager::getInstance()->loadArchive( appDir, "app" );
		MResourceManager::getInstance()->loadArchive( appDir + "resource", "resource" );
	}
	catch( MIoException ae )
	{
		MLogger::logError( ae.getExceptionDescripton() );
		return false;
	}

	MAudioEngine::initDxDescs();

	ivPtModule = new LMModule();
	MSaxTreeDocument doc;
	doc.parse("resource/module/module.xml");
	ivPtModule->load(doc.getRoot());

	// debug storing....
	{
		MTreeNode* pNode = ivPtModule->save();
		MTreeDocumentUtils::store(pNode, "c:/module.xml");
		delete pNode;
	}

	ivPtWindow = new LMWindow(ivPtModule);
	ivPtWindow->create( MRect( 10,10, 968, 704 ), 0 );
	ivPtWindow->centerWindow();
	ivPtWindow->setText( getAppName() );
	ivPtWindow->setVisible( true );

	ivPtEngine = new MAudioEngine(ivPtWindow);
	ivPtEngine->create(ivPtModule);
	ivPtEngine->start();

	return true;
}

/** invoked when app exists */
bool LMApp::onExit()
{
	try
	{
		if(ivPtEngine)
		{
			if(ivPtEngine->isPlaying())
				ivPtEngine->stop();
			delete ivPtEngine;
			ivPtEngine = 0;
		}
	}
	catch(...)
	{
		MLogger::logWarning( "LMApp::onExit: failed deleting engine" );
	}

	try
	{
		SAFE_DELETE(ivPtModule);
	}
	catch(...)
	{
		MLogger::logWarning( "LMApp::onExit: failed deleting module" );
	}

	try
	{
		MResourceManager::release();
	}
	catch( MIoException ae )
	{
		MLogger::logWarning( ae.getExceptionDescripton() );
		return false;
	}

	MAudioEngine::releaseDxDescs();
	MProperties::release();

	return true;
}
